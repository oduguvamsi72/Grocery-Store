document.addEventListener("DOMContentLoaded", () => {
    loadCart();
});

// Load Cart Items
function loadCart() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let cartItemsContainer = document.getElementById("cart-items");
    let totalPrice = 0;

    cartItemsContainer.innerHTML = "";

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = "<p>Your cart is empty. 🛒</p>";
        return;
    }

    cart.forEach((item, index) => {
        let itemTotal = (parseFloat(item.price.replace("$", "")) * item.quantity).toFixed(2);
        totalPrice += parseFloat(itemTotal);

        let cartItem = document.createElement("div");
        cartItem.classList.add("cart-item");
        cartItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <div class="cart-details">
                <h3>${item.name}</h3>
                <p>Price: $${item.price}</p>
                <p>Quantity: <input type="number" value="${item.quantity}" min="1" data-index="${index}"></p>
                <button class="remove-btn" data-index="${index}">Remove</button>
            </div>
        `;
        cartItemsContainer.appendChild(cartItem);
    });

    document.getElementById("total-price").textContent = totalPrice.toFixed(2);

    // Add event listeners for quantity updates and remove buttons
    document.querySelectorAll(".cart-item input").forEach(input => {
        input.addEventListener("change", updateQuantity);
    });

    document.querySelectorAll(".remove-btn").forEach(button => {
        button.addEventListener("click", removeItem);
    });
}

// Update Quantity
function updateQuantity(event) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let index = event.target.getAttribute("data-index");
    let newQuantity = parseInt(event.target.value);

    if (newQuantity < 1) return;

    cart[index].quantity = newQuantity;
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart();
}

// Remove Item
function removeItem(event) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let index = event.target.getAttribute("data-index");

    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart();
}

// Checkout Button Click
document.getElementById("checkout-btn").addEventListener("click", () => {
    alert("Order placed successfully! 🎉");
    localStorage.removeItem("cart");
    window.location.href = "index.html";
});
